package consultas;

/**
 * @author du
 *
 */
public class MostraConsultas {

	public static void main(String[] args) {
		//System.out.println("Consulta primeira carta "+ new ExemploConsultas().respostaPrimeiraCartaTeste(52,16,1));		
		//System.out.println("Consulta primeira carta "+ new ExemploConsultas().respostaPrimeiraCarta());
		//System.out.println("1 test");
		//System.out.println("Consulta segunda carta "+ new ExemploConsultas().respostaSegundaCarta());
		//System.out.println("2 test");
		//System.out.println("Consulta terceira carta "+ new ExemploConsultas().respostaTerceiraCarta());
		// CHAMADAS
		//System.out.println("Consulta chamou envido "+ new ExemploConsultas().respostaChamarEnvido(1, 33));
		//System.out.println("Consulta chamou truco "+ new ExemploConsultas().respostaChamarTruco(3, 2, 1, 2, 16, 24, 5, 1));
		//System.out.println("Consulta chamou Real envido "+ new ExemploConsultas().respostaChamarRealEnvido(	1, 33));
		//System.out.println("Consulta chamou retruco "+ new ExemploConsultas().respostaChamarRetruco(52, 16, 1, 2, 16, 24, 5, 2));
		//System.out.println("Consulta chamou Falta envido "+ new ExemploConsultas().respostaChamarFaltaEnvido(2, 33));
		//System.out.println("Consulta chamou Vale4 "+ new ExemploConsultas().respostaChamarVale4(52, 16, 1, 2, 16, 24, 5, 1));
		// ACEITAMENTOS
		//System.out.println("Consulta aceitou envido "+ new ExemploConsultas().respostaAceitarEnvido(2, 33));
		//System.out.println("Consulta aceitou truco "+ new ExemploConsultas().respostaAceitarTruco(3, 2, 1, 2, 16, 24, 5, 1));
		//System.out.println("Consulta aceitou Real envido "+ new ExemploConsultas().respostaAceitarRealEnvido(2, 33));
		//System.out.println("Consulta aceitou Retruco "+ new ExemploConsultas().respostaAceitarRetruco(3, 2, 1, 2, 16, 24, 5, 1));		
		//System.out.println("Consulta aceitou Falta envido "+ new ExemploConsultas().respostaAceitarFaltaEnvido(2, 33));
		//System.out.println("Consulta aceitou Vale 4 "+ new ExemploConsultas().respostaAceitarVale4(3, 2, 1, 2, 16, 24, 5, 1));
		
	}

}